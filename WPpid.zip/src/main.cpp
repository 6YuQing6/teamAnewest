#include "vex.h"

using namespace vex;
competition Competition;

/*---------------------------------------------------------------------------*/
/*                             VEXcode Config                                */
/*                                                                           */
/*  Before you do anything else, start by configuring your motors and        */
/*  sensors using the V5 port icon in the top right of the screen. Doing     */
/*  so will update robot-config.cpp and robot-config.h automatically, so     */
/*  you don't have to. Ensure that your motors are reversed properly. For    */
/*  the drive, spinning all motors forward should drive the robot forward.   */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/*                             JAR-Template Config                           */
/*                                                                           */
/*  Where all the magic happens. Follow the instructions below to input      */
/*  all the physical constants and values for your robot. You should         */
/*  already have configured your robot manually with the sidebar configurer. */
/*---------------------------------------------------------------------------*/

motor leftMotorA = motor(PORT18, ratio6_1, true); 
motor leftMotorB = motor(PORT19, ratio6_1, true);
motor leftMotorC = motor(PORT20, ratio6_1, true);
motor leftMotorD = motor(PORT1/*placeholder!!!!*/, ratio18_1, true);//also placeholder!!!!
motor_group LeftDriveSmart = motor_group(leftMotorA, leftMotorB, leftMotorC, leftMotorD);

motor rightMotorA = motor(PORT11, ratio6_1, false);
motor rightMotorB = motor(PORT12, ratio6_1, false);
motor rightMotorC = motor(PORT13, ratio6_1, false);
motor rightMotorD = motor(PORT1/*placeholder!!!!*/, ratio18_1, true);//also placeholder!!!!
motor_group RightDriveSmart = motor_group(rightMotorA, rightMotorB, rightMotorC, rightMotorD);

inertial DrivetrainInertial = inertial(PORT21);
smartdrive Drivetrain = smartdrive(LeftDriveSmart, RightDriveSmart, DrivetrainInertial, 10.21018, 10.8, 12, inches, 0.6);
//controller Controller1 = controller(primary);
motor Intake = motor(PORT14, ratio6_1, false);
motor Cata = motor(PORT15, ratio6_1, false);
motor Cata1 = motor(PORT16, ratio6_1, false);


Drive chassis(

//Specify your drive setup below. There are seven options:
//ZERO_TRACKER_NO_ODOM, ZERO_TRACKER_ODOM, TANK_ONE_ENCODER, TANK_ONE_ROTATION, TANK_TWO_ENCODER, TANK_TWO_ROTATION, HOLONOMIC_TWO_ENCODER, and HOLONOMIC_TWO_ROTATION
//For example, if you are not using odometry, put ZERO_TRACKER_NO_ODOM below:
ZERO_TRACKER_NO_ODOM,

//Add the names of your Drive motors into the motor groups below, separated by commas, i.e. motor_group(Motor1,Motor2,Motor3).
//You will input whatever motor names you chose when you configured your robot using the sidebar configurer, they don't have to be "Motor1" and "Motor2".

//Left Motors:
LeftDriveSmart,

//Right Motors:
RightDriveSmart,

//Specify the PORT NUMBER of your inertial sensor, in PORT format (i.e. "PORT1", not simply "1"):
PORT21,

//Input your wheel diameter. (4" omnis are actually closer to 4.125"):
3.25,

//External ratio, must be in decimal, in the format of input teeth/output teeth.
//If your motor has an 84-tooth gear and your wheel has a 60-tooth gear, this value will be 1.4.
//If the motor drives the wheel directly, this value is 1:
0.6,

//Gyro scale, this is what your gyro reads when you spin the robot 360 degrees.
//For most cases 360 will do fine here, but this scale factor can be very helpful when precision is necessary.
360,

/*---------------------------------------------------------------------------*/
/*                                  PAUSE!                                   */
/*                                                                           */
/*  The rest of the drive constructor is for robots using POSITION TRACKING. */
/*  If you are not using position tracking, leave the rest of the values as  */
/*  they are.                                                                */
/*---------------------------------------------------------------------------*/

//If you are using ZERO_TRACKER_ODOM, you ONLY need to adjust the FORWARD TRACKER CENTER DISTANCE.

//FOR HOLONOMIC DRIVES ONLY: Input your drive motors by position. This is only necessary for holonomic drives, otherwise this section can be left alone.
//LF:      //RF:    
PORT1,     -PORT2,

//LB:      //RB: 
PORT3,     -PORT4,

//If you are using position tracking, this is the Forward Tracker port (the tracker which runs parallel to the direction of the chassis).
//If this is a rotation sensor, enter it in "PORT1" format, inputting the port below.
//If this is an encoder, enter the port as an integer. Triport A will be a "1", Triport B will be a "2", etc.
3,

//Input the Forward Tracker diameter (reverse it to make the direction switch):
2.75,

//Input Forward Tracker center distance (a positive distance corresponds to a tracker on the right side of the robot, negative is left.)
//For a zero tracker tank drive with odom, put the positive distance from the center of the robot to the right side of the drive.
//This distance is in inches:
-2,

//Input the Sideways Tracker Port, following the same steps as the Forward Tracker Port:
1,

//Sideways tracker diameter (reverse to make the direction switch):
-2.75,

//Sideways tracker center distance (positive distance is behind the center of the robot, negative is in front):
5.5

);

int current_auton_selection = 0;
bool auto_started = false;

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  default_constants();

  while(auto_started == false){            //Changing the names below will only change their names on the
    Brain.Screen.clearScreen();            //brain screen for auton selection.
    // switch(current_auton_selection){       //Tap the brain screen to cycle through autons.
    //   case 0:
    //     Brain.Screen.printAt(50, 50, "Drive Test");
    //     break;
    //   case 1:
    //     Brain.Screen.printAt(50, 50, "Drive Test");
    //     break;
    //   case 2:
    //     Brain.Screen.printAt(50, 50, "Turn Test");
    //     break;
    //   case 3:
    //     Brain.Screen.printAt(50, 50, "Swing Test");
    //     break;
    //   case 4:
    //     Brain.Screen.printAt(50, 50, "Full Test");
    //     break;
    //   case 5:
    //     Brain.Screen.printAt(50, 50, "Odom Test");
    //     break;
    //   case 6:
    //     Brain.Screen.printAt(50, 50, "Tank Odom Test");
    //     break;
    //   case 7:
    //     Brain.Screen.printAt(50, 50, "Holonomic Odom Test");
    //     break;
    // }
    // if(Brain.Screen.pressing()){
    //   while(Brain.Screen.pressing()) {}
    //   current_auton_selection ++;
    // } else if (current_auton_selection == 8){
    //   current_auton_selection = 0;
    // }
    task::sleep(10);
  }
}

void autonomous(void) {

////////////////////////////////BEST WP PID VER////////////////////////////////////

  /*
  chassis.set_drive_constants(11, 1.2, 0.04, 15, 0); //Drivetrain.setTurnVelocity(100, pct);
  chassis.set_heading_constants(6, .4, 0, 1, 0); //Drivetrain.setTurnConstant(0.45);
  chassis.set_turn_constants(12, .4, .03, 3, 15); // Drivetrain.setDriveVelocity(100, pct);
  chassis.set_swing_constants(12, .3, .001, 2, 15);
  chassis.set_drive_exit_conditions(2, 60, 5000);
  chassis.set_turn_exit_conditions(1, 300, 3000);
  chassis.set_swing_exit_conditions(1, 300, 3000);
  */

  //push starting ball next to goal
  double angle = 0;
  chassis.set_heading(0);
  Right_Wing.set(true); //same
  wait(0.5, sec);//
  Right_Wing.set(false);//

  //getting center ball
  Intake.spin(forward, 100,pct); //
  chassis.drive_distance(45); //  Drivetrain.driveFor(forward, 45, inches);
  
  chassis.drive_distance(-4);
  Intake.stop();
  //chassis.set_drive_constants(12, 1.2, 0.04, 15, 0);
  chassis.drive_distance(-45);

  //getting match load ball (likely need to refine!!!)
  chassis.turn_to_angle(-90 + angle);
  angle += -90;
  chassis.set_drive_constants(9, 0.8, 0.04, 15, 0); // Drivetrain.setDriveVelocity(15, pct);
  chassis.drive_distance(24);
  chassis.turn_to_angle(15 + angle); //Prob delete this
  angle += 15;
  Balancer.set(true);
  chassis.drive_distance(-17);
  Balancer.set(false);

  //scoring 2 balls 
  //chassis.set_drive_constants(11, 1.2, 0.04, 15, 0);//Drivetrain.setDriveVelocity(100, pct);
  chassis.turn_to_angle(-10 + angle);
  angle += -10;
  chassis.set_drive_constants(10, 1, 0.04, 15, 0);//Drivetrain.setDriveVelocity(45, pct);
  chassis.drive_distance(17);
  chassis.turn_to_angle(160);
  angle = 160;
  chassis.set_drive_constants(11, 1.2, 0.04, 15, 0);//Drivetrain.setDriveVelocity(100,pct);
  chassis.drive_distance(-36);//idk (change)

  //going to touch bar / push 2 balls to other side
  chassis.turn_to_angle(180);
  angle = 180;
  chassis.drive_distance(5);
  chassis.turn_to_angle(-30 + angle);
  chassis.drive_distance(25);
  
  //my own shit
  chassis.turn_to_angle(90);
  Intake.spin(reverse);
  chassis.set_drive_constants(8, 1, 0.04, 15, 0);
  chassis.drive_distance(20); //idk change to liking :)


  


  
//    /////////BEST WP/////////////////////
//     Drivetrain.setTurnVelocity(100, pct);
//   Drivetrain.setTurnConstant(0.45);
//   Drivetrain.setDriveVelocity(100, pct);
//   Drivetrain.setHeading(5,degrees);
//   Right_Wing.set(true);
//   wait(0.5, sec);
//   Right_Wing.set(false);
//   Intake.spin(forward, 100,pct);
//   Drivetrain.driveFor(forward, 45, inches);
  
//   /*
//   Drivetrain.turnFor(90, deg);
//   Left_Wing.set(true);
//   Drivetrain.driveFor(forward, 13, inches);
//   Left_Wing.set(false);
//   Drivetrain.driveFor(reverse, 13, inches);
  
//   Drivetrain.turnFor(-90, deg);
//   */
//   Drivetrain.driveFor(reverse, 4, inches);
//   Intake.stop();
//   Drivetrain.setDriveVelocity(100, pct);
//   Drivetrain.driveFor(reverse, 45, inches);
//   Drivetrain.turnFor(-90, deg);
//   Drivetrain.setDriveVelocity(15, pct);
//   Drivetrain.driveFor(forward,24, inches);
//   Drivetrain.turnFor(15,deg);
//   Balancer.set(true);
//   Drivetrain.driveFor(reverse, 17, inches);
//   Balancer.set(false);
//   Drivetrain.setDriveVelocity(100, pct);
//   Drivetrain.turnFor(-10,degrees);
//   Drivetrain.setDriveVelocity(45, pct);
//   Drivetrain.driveFor(forward, 17, inches);
//   Drivetrain.turnToHeading(160,deg);//change thi6
//   Drivetrain.setDriveVelocity(100, pct);
//   Drivetrain.drive(reverse);
//   wait(0.5, sec);
//   Drivetrain.stop();
//   Drivetrain.driveFor(forward, 5, inches);
//   Drivetrain.turnFor(-30, deg);
//   Drivetrain.driveFor(forward, 25, inches);
//   Drivetrain.turnFor(-40+-180, deg);
//   Drivetrain.setDriveVelocity(100,pct);
//   Drivetrain.drive(reverse);
//   wait(1, sec);
//   Drivetrain.setDriveVelocity(15, pct);
//   Drivetrain.drive(reverse),
//   wait(1, sec);
//   Drivetrain.driveFor(forward, 5, inches);
//   Drivetrain.turnFor(180, deg);
//   Intake.spin(reverse);
//   Drivetrain.driveFor(forward, 3, inches);
    



// // chassis.moveTo(0, 0, 5000);
// // chassis.moveTo(9.365, 9.6, 5000);
// // chassis.moveTo(9.6, -4.214, 5000);

// // chassis.moveTo(87.098, -4.214, 5000);
// // chassis.moveTo(107.468, 18.965, 5000);
// // chassis.moveTo(107.702, 31.14, 5000);
// // chassis.moveTo(107.936, 18.731, 5000);
// // chassis.moveTo(55.958, 17.092, 5000);
// // chassis.moveTo(91.078, 41.91, 5000);
// // chassis.moveTo(54.553, 38.866, 5000);
// // chassis.moveTo(55.724, 55.022, 5000);
// // chassis.moveTo(91.546, 55.958, 5000);
// // chassis.moveTo(55.256, 66.26, 5000);
// // chassis.moveTo(55.724, 95.293, 5000);
// // chassis.moveTo(89.439, 68.835, 5000);








//   current_auton_selection= 4;
//   switch(current_auton_selection){  
//     case 0:
//       drive_test(); //This is the default auton, if you don't select from the brain.
//       break;        //Change these to be your own auton functions in order to use the auton selector.
//     case 1:         //Tap the screen to cycle through autons.
//       drive_test();
//       break;
//     case 2:
//       turn_test();
//       break;
//     case 3:
//       swing_test();
//       break;
//     case 4:
//       full_test();
//       break;
//     case 5:
//       odom_test();
//       break;
//     case 6:
//       tank_odom_test();
//       break;
//     case 7:
//       holonomic_odom_test();
//       break;
//  }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.

    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................

    //Replace this line with chassis.control_tank(); for tank drive 
    //or chassis.control_holonomic(); for holo drive.
    chassis.control_arcade();

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
